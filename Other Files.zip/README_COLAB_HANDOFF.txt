SIGNAL OR REDUNDANCY? -- COLAB HANDOFF

Primary Python input: COLAB_FROZEN_PANEL.csv.gz
R benchmark forecasts: R_ALL_FORECASTS.csv.gz
Primary R econometric model: positivity-preserving Log-HAR-X with training-only Duan smearing
Feature definitions: feature_manifest.csv
Fold definitions: fold_registry.csv and log_har_refit_registry.csv

Do NOT reconstruct targets or technical indicators in Python.
Do NOT use random train/test splits.
Fit every imputer/scaler only on the training portion of each chronological fold.
Use 5 days as the primary horizon; 10 and 20 days are robustness horizons.
Primary comparison: B_primitive vs C_primitive_plus_TI.
Python models to fit next: LightGBM and compact pooled LSTM.

